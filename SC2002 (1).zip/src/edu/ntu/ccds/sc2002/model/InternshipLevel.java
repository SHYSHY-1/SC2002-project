package edu.ntu.ccds.sc2002.model;

public enum InternshipLevel { BASIC, INTERMEDIATE, ADVANCED }
