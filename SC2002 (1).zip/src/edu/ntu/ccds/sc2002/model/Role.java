package edu.ntu.ccds.sc2002.model;

public enum Role {
    STUDENT,
    COMPANY_REPRESENTATIVE,
    CAREER_CENTER_STAFF
}