package edu.ntu.ccds.sc2002.model;

public enum InternshipStatus { PENDING, APPROVED, REJECTED, FILLED }
